<?php
// @codingStandardsIgnoreFile
/**
 * Plugin Name: Mamo Business
 * Description: This plugin allows businesses to utilise Mamo to receive online payments from their customers through cards, Apple Pay and Google Pay. Supports WooCommerce Subscriptions.
 * Version: 1.2.1
 * Author: Mamo Limited
 * Author URI: https://mamopay.com
 * Developer: Mamo Limited
 * Developer URI: https://mamopay.com
 * Text Domain: mamo-pay
 * Domain Path: /languages/
 *
 * Woo: 12345:342928dfsfhsf8429842374wdf4234sfd
 * WC requires at least: 6.0
 * WC tested up to: 7.0.1
 *
 * @package    mamo-pay
 * License: GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly .
}

/* Plugin Name */
$cweb_plugin_name = 'Mamo Business';

/* Use Domain as the folder name */
$plugin_text_domain = 'mamo-pay';


/**
 * The code that runs during plugin activation.
 */
function mamopay_activate_this_plugin() {
	if ( class_exists( 'WooCommerce' ) ) {
		include_once plugin_dir_path( __FILE__ ) . 'includes/classes/class-plugin-activator.php';
		Plugin_Activator::activate();
		flush_rewrite_rules();
	} else {
		esc_html_e( 'Sorry, but the Mamo Business plugin requires the Woocmmerce plugin to be installed and active.', 'mamo-pay' );
		?>
		<br>
		<a href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>" ><?php esc_html_e( '&laquo; Return to Plugins', 'mamo-pay' ); ?></a>
		<?php 
		wp_die();
	} 
} 
/**
 * The code that runs during plugin deactivation.
 */
function mamopay_deactivate_this_plugin() {
	include_once plugin_dir_path( __FILE__ ) . 'includes/classes/class-plugin-deactivator.php';
	Plugin_Deactivator::deactivate();
} 
/**
 * Mamopay_detect_plugin_deactivation
 *
 * @param string $plugin Describe what this parameter is.
 * @param string $network_activation Describe what this parameter is.
 * To prevent the issue if someone directly deactivate the woocommerce plugin.
 */
function mamopay_detect_plugin_deactivation( $plugin, $network_activation ) {
	if ( 'woocommerce/woocommerce.php' === $plugin ) {
		esc_html_e( 'Sorry, but Mamo Business plugin is active. Please deactivate Mamo Business plugin first to deactivate the Woocmmerce plugin.', 'mamo-pay' );
		?>
		<br>
		<a href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>" ><?php esc_html_e( ' &laquo; Return to Plugins', 'mamo-pay' ); ?></a>
		<?php 
		wp_die();
	} 
} 

add_action( 'deactivated_plugin', 'mamopay_detect_plugin_deactivation', 10, 2 );
/* Register Hooks For Start And Deactivate */
register_activation_hook( __FILE__, 'mamopay_activate_this_plugin' );
register_deactivation_hook( __FILE__, 'mamopay_deactivate_this_plugin' );
/**
 * The core plugin class that is used to define internationalization,
*/
require plugin_dir_path( __FILE__ ) . 'includes/classes/class-cwebclass.php';
/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since 1.0.0
 */
function mamopay_run_plugin_name() {
	$plugin = new CwebClass();
	$plugin->run();
} 
mamopay_run_plugin_name();
/* Constant */
define( 'CWEB_FS_PATH1', plugin_dir_path( __FILE__ ) );
define( 'CWEB_WS_PATH1', plugin_dir_url( __FILE__ ) );
// Declares Common Function File .
require plugin_dir_path( __FILE__ ) . 'includes/function/fucntions.php';
require plugin_dir_path( __FILE__ ) . 'includes/function/class-wc-mamopay-gateway.php';
add_action( 'init', 'mamopay_language_text_domain' );

/** Mamopay_language_text_domain .
 */
function mamopay_language_text_domain() {
	$languagepath = plugin_dir_path( __FILE__ ) . 'languages/';
	load_plugin_textdomain( 'mamopay', false, $languagepath );
} 
