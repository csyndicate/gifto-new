// @codingStandardsIgnoreFile
/**
 * Source: https://mamopay.com
 * Version: 1.1.0

 * @package WordPress
 * Original authors:
 *  - Mamo Limited
 *

 * Mamo Business added by:
 *   Mamo Limited
 *   mamopay.com
 **/

jQuery( document ).ready(
	function() {
		jQuery( 'form.checkout' ).on(
			'click',
			'input[name^="selected_mamo_payment_method"]',
			function() {
				jQuery( 'body' ).trigger( 'update_checkout' );
			}
		);

		jQuery( 'body' ).find( '#iframe-mamo-checkout body' ).css( "background-color", "yellow" );
		jQuery( 'body' ).on(
			'click',
			'#mamo-checkout_1',
			function(e) {
				var ajax_url = mamopay_obj.ajaxurl;
				console.log( 'ajax_url' + ajax_url );
				var reqq = new Array();
				jQuery("p[class*=validate-required]").each(function(){
					reqq.push(jQuery(this).attr('id'));
				});
				jQuery.ajax(
					{
						type: 'POST',
						url: ajax_url,
						beforeSend: function (xhr){
						},
						data: {
							'form_data': 'data',
							'fields': jQuery( 'form.checkout' ).serializeArray(),
							'action': 'mamopay_create_order_cstm',
							'user_id': mamopay_obj.uid,
							'reqq' : reqq
						},
						success: function (response){
							var result      = JSON.parse( response );
							var consumerUrl = window.location.href;
							if ( result.redirect && result.result == 'success' ) {
								mamopay_ajax_popup( result.redirect, consumerUrl );
							} else {
								var error_message = result.message;
								jQuery( 'form.checkout' ).prepend( '<ul class="woocommerce-error" role="alert"><li>  '+error_message+'	</li></ul>' );
								jQuery( [document.documentElement, document.body] ).animate(
									{
										scrollTop: jQuery( ".woocommerce-notices-wrapper" ).offset().top
									},
									2000
								);
							}
						}
					}
				);
			}
		);


		window.onhashchange = mamopay_openpopuhash;


	}
);


function mamopay_openpopuhash() {
	var currentHash = location.hash; 
	if(currentHash !="") {
		currentHash = currentHash.replace('#', '');
		var consumerUrl = window.location.href;
		mamopay_ajax_popup(currentHash, consumerUrl);
	} 
} 

function scroll_to_notices() {
	var scrollElement = jQuery( '.woocommerce-NoticeGroup-updateOrderReview, .woocommerce-NoticeGroup-checkout' );
	if ( ! scrollElement.length ) {
		scrollElement = jQuery( 'form.checkout' );
	} 
	jQuery.scroll_to_notices( scrollElement );
} 

function mamopay_getDomain(url) {
	const parts = url.split( "/" );
	if ( url.startsWith( "http://" ) ) {
		return parts[0] + "//" + parts[2]
	} else if ( url.startsWith( "https://" ) ) {
		return parts[0] + "//" + parts[2]
	} else {
		return null
	}
}

function mamopay_display_iframe_divs() {
	jQuery('.mamopay_iframe_main_div').css('display','block');
	jQuery('.mamopay_iframe_container').css('display','block');
	jQuery('.mamopay_iframe_loader').css('display','block');
}

function mamopay_hide_iframe_divs() {
	jQuery('.mamopay_iframe_main_div').css('display','none');
	jQuery('.mamopay_iframe_container').css('display','none');
	jQuery('.mamopay_iframe_loader').css('display','none');
	jQuery('body').find('.mamopay_iframe_main_div').css('display','none');
	window.location.hash="";
	location.reload();
}

function mamopay_ajax_popup(serverUrl, consumerUrl) {
	try {
		mamopay_display_iframe_divs();
		jQuery('.mamopay_iframe_loader').css('display','block');
		jQuery('.woocommerce-checkout .blockOverlay').css('display', 'none');
		domainName   = mamopay_getDomain( serverUrl );
		const iframe = document.getElementById( "iframe-mamo-checkout" );
		if (iframe) {
			console.log( 'loaded 2 ' );
			iframe.src           = `${serverUrl}?consumer=${consumerUrl}`;
			
			// document.body.appendChild(iframe); .
			iframe.onload = () => {
				jQuery('.woocommerce-checkout .blockOverlay').css('display', 'none');
				iframe.style.display = "block";
				jQuery('.mamopay_iframe_loader').css('display','none');

				window.addEventListener(
					"message",
					event => {
						jQuery( '.mamopay_iframe_loader' ).css( 'display', 'none' );
						// const iframe = document.getElementById( "iframe-mamo-checkout" );.
							const iframeDoc = document.getElementById( "iframe-mamo-checkout" ).contentDocument;
						if ( iframeDoc && iframeDoc.querySelector( "html" )) {
							console.log( 'loaded 5 ' );
							// const iframeHTML=iframeDoc&&iframeDoc.querySelector("html"); ,
							// iframeHTML.style.backgroundColor="transparent"; .
						}
						if ( event.origin !== domainName ) {
							console.log( 'domain not matching' );
							return;
						}
						if ( event.data === "closeIframe" || event.message === "closeIframe" ) {
							mamopay_hide_iframe_divs();
							iframe.style.display = "none";
						}
						if ( event.data === "checkout-complete" || event.message === "checkout-complete" ) {
							mamopay_hide_iframe_divs();
							iframe.style.display = "none";
						}
						if ( event.data === "connectionEstablished" || event.message === "connectionEstablished" ) {
							console.log( 'loaded 6 ' );
							console.log( "connection establised" );
						}
						if ( event.data.type && event.data.type === "confirmation_required" ) {
							mamopay_hide_iframe_divs();
							iframe.style.display = "none";
							window.location.replace( event.data.payload )
						} 
					} 
				)
			} 
		} else {
			const iframe = document.createElement( "iframe" );
			iframe.src   = `${serverUrl} ? consumer = ${consumerUrl}`;
			iframe.setAttribute( "crossorigin","anonymous" );
			iframe.setAttribute( "id","iframe-mamo-checkout" );
			iframe.style.position = "fixed";
			iframe.style.top      = "0";
			iframe.style.left     = "0";
			iframe.style.width    = "100%";
			iframe.style.height   = "100%";
			iframe.style.display  = "block";
			document.body.appendChild( iframe );
			iframe.onload               = () => {
				window.addEventListener(
					"message",
					event => {
						const iframe    = document.getElementById( "iframe-mamo-checkout" );
						const iframeDoc = document.getElementById( "iframe-mamo-checkout" ).contentDocument;
						if ( iframeDoc && iframeDoc.querySelector( "html" )) {
							const iframeHTML                 = iframeDoc && iframeDoc.querySelector( "html" );
							iframeHTML.style.backgroundColor = "transparent";
						}
						if ( event.origin !== domainName ) {
							return;
						} 
						if ( event.data === "closeIframe" || event.message === "closeIframe" ) {
							iframe.style.display = "none"
						} if ( event.data === "checkout-complete" || event.message === "checkout-complete" ) {
							iframe.style.display = "none"
						} if ( event.data === "connectionEstablished" || event.message === "connectionEstablished" ) {
							console.log( "connection establised" );
						} if ( event.data.type && event.data.type === "confirmation_required" ) {
							iframe.style.display = "none";
							window.location.replace( event.data.payload )
						} 
					} 
				)
			} 

		}
	} catch (e) {
		console.error( "#mamo-checkout.onClick() error - ",e )
	}
}
