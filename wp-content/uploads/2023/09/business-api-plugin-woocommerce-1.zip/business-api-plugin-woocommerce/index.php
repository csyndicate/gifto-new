<?php
// @codingStandardsIgnoreFile
/**
 * Silence is golden
 * Description: This index
 *
 * @package    mamo-pay
 */
