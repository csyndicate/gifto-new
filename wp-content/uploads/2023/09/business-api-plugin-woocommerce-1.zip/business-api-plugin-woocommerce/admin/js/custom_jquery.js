// @codingStandardsIgnoreFile
/**
 * Source: https://mamopay.com
 * Version: 1.1.0
 *
 * @package WordPress
 * Original authors:
 *  - Mamo Limited
 *
 *
 * Mamo Business added by:
 *   Mamo Limited
 *   mamopay.com
 **/

jQuery( document ).ready(
	function () {
		if (jQuery( '.mamopay_live_sandbox_toggle' ).is( ":checked" )) {
			jQuery( ".mamopay_liveurlclass" ).parents( 'tr' ).css( 'display', 'none' );
			jQuery( ".mamopay_livekeyclass" ).parents( 'tr' ).css( 'display', 'none' );
		} else {
			jQuery( ".mamopay_sandbox_urlclass" ).parents( 'tr' ).css( 'display', 'none' );
			jQuery( ".mamopay_sandbox_keyclass" ).parents( 'tr' ).css( 'display', 'none' );
		}

		jQuery( '.mamopay_live_sandbox_toggle' ).click(
			function () {
				jQuery( ".mamopay_liveurlclass" ).parents( 'tr' ).fadeToggle( 500 );
				jQuery( ".mamopay_livekeyclass" ).parents( 'tr' ).fadeToggle( 500 );

				jQuery( ".mamopay_sandbox_urlclass" ).parents( 'tr' ).fadeToggle( 500 );
				jQuery( ".mamopay_sandbox_keyclass" ).parents( 'tr' ).fadeToggle( 500 );
			}
		);

		jQuery( '.mamopayurladmin' ).on(
			'blur',
			function () {
				var url = jQuery( this ).val();
				console.log( 'val is ' + url );
				if ( ! MamoPayisValidUrl( url )) {
					alert( 'Please add valid Url' );
				}
			}
		);

		const MamoPayisValidUrl = urlString => {
			try {
				return Boolean( new URL( urlString ) );
			} catch (e) {
				return false;
			}
		}

	}
);
