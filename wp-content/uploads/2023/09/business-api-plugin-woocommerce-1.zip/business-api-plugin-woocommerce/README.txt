﻿=== Mamo Pay ===
Contributors: Mamo Limited
Tags: Mamo, woocommerce payment plugin, cards payment, apple pay, google pay, subscriptions
Requires at least: 4.7
Requires PHP: 7.0
Tested up to: 6.1
Stable tag: 1.0.1
Version: 1.0.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html


Mamo Business - Receive payments online

== Description == 

This extension to the WooCommerce WP plugin that will allow developers/ merchants building
Woocommerce websites to gain access to our payment gateway.
Customers using the merchant’s website will be able to pay by card, Apple Pay and Google Pay
Clicking on this button will redirect the customer to Mamo’s payment page where they
can enter their payment details. Upon completion, they will be redirected back to the
merchant’s website (or a success page configured by them). Customers will not be
entering their payment details directly on the merchant’s website.

Note: Min amount is AED 2.00


== Installation ==

1. Upload `unzipped plugin folder` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Make sure that before activating the Mamo Business plugin, the woocommerce plugin is installed and activated.
4. Register on <a href="https://www.mamopay.com/">Mamo Pay</a> to get api key.
5. Add this api key in woocommerce settings->Payment tab and then save.

== Frequently Asked Questions ==

= Will the customers receive an email after purchase? =

Yes, you will get default email of woocommerce after payment.

= Can It be tested before going live? =

Yes, you can test it be enabling the sandbox mode from woocommerce settings.

= will It accept all payment cards? =

All credit / debit cards + Apple Pay + Google Pay

== Upgrade Notice ==
None.

== Changelog ==

= 1.0.0
* First Release

 Supports almost all cards.

== Screenshots ==
1. Config Screenshot.png

