<?php
// @codingStandardsIgnoreFile
/**
 * Plugin Name: Mamo Business
 * Description: Define the internationalization functionality. Loads and defines the internationalization files for this plugin.So that it is ready for translation.
 * Version: 1.1.0
 *
 * @wordpress-plugin
 * Author URI:  https://mamopay.com/
 * @file
 * Description: The public-facing functionality of the plugin. This class include the public assets like css file and js file.
 * @link  https://mamopay.com/
 * @since 1.0.0
 *
 * @package    mamo-pay
 * @subpackage mamo-pay/includes
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the dashboard-specific stylesheet and JavaScript.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly .
}
/** Cweb_Public */
class Cweb_Public {
	/**
	 * The ID of this plugin.
	 *
	 * @since  1.0.0
	 * @var    string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since  1.0.0
	 * @var    string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since 1.0.0
	 * @param string $plugin_name Describe what this parameter is.
	 * @param string $version The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;
	}
	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_scripts() {

		global $plugin_text_domain;
		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_style( 'mamopay_css', CWEB_WS_PATH1 . 'public/assets/css/components.css', array(), $this->version );
		wp_enqueue_script( 'mamopay_js', CWEB_WS_PATH1 . 'public/assets/js/mamopay.js', array( 'jquery' ), $this->version, false );
	}
}
