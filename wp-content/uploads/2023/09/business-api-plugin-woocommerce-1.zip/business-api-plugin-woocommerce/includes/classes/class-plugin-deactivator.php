<?php
// @codingStandardsIgnoreFile
// phpcs:ignoreFile
/**
 * Plugin Name: Mamo Business
 * Description: This class include the function related to actvation of the plugin
 * Version: 1.1.0
 *
 * @wordpress-plugin
 * Author URI:  https://mamopay.com/
 * @file
 * @package    mamo-pay
 * Description: The public-facing functionality of the plugin. This class include the public assets like css file and js file.
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the dashboard-specific stylesheet and JavaScript.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly .
}

/** Plugin_Deactivator */
class Plugin_Deactivator {

	/** De-activate Class **/
	public static function deactivate() {
		global $wpdb;
		/**
		 * The code that runs during plugin deactivation.
		*/

	}
}


