<?php
// @codingStandardsIgnoreFile
// phpcs:ignoreFile
/**
 * Plugin Name: Mamo Business
 * Description: This class include the function related to actvation of the plugin
 * Version: 1.1.0
 *
 * @wordpress-plugin
 * Author URI:  https://mamopay.com/
 * @file
 * Description: The public-facing functionality of the plugin. This class include the public assets like css file and js file.
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the dashboard-specific stylesheet and JavaScript.
 * @package    mamo-pay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly .
}

/** Plugin_Activator */
class Plugin_Activator {

	/** Activate Class **/
	public static function activate() {
		global $wpdb;
		/**
		 * The code that runs during plugin activation.
		*/

	}
}


