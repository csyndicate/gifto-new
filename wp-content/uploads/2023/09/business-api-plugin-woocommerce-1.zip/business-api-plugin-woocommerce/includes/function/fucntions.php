<?php
// @codingStandardsIgnoreFile
// phpcs:ignoreFile
/**
 *
 * Description: This plugin allows businesses to utilise Mamo to receive online payments from their customers through cards, Apple Pay and Google Pay. Supports WooCommerce Subscriptions.
 *
 * @wordpress-plugin
 * Description: Functions and hooks used in Plugin
 *
 * @package  mamo-pay
 * Author:   Mamo Limited
 * Author URI: https://mamopay.com
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
} 

/**
 * Functon to check the payment status. This function will change woocommerce order status when user will come back to website after make payment on Mamo Pay
 */
add_filter( 'woocommerce_thankyou_order_received_text', 'mamopay_orderprocessing', 10, 2 );

/**
 * Mamopay_orderprocessing
 *
 * @param string $str Describe what this parameter is.
 * @param string $order Describe what this parameter is.
 */
function mamopay_orderprocessing( $str, $order ) {
	global $wp, $wpdb;
	$_get_lower = array_change_key_case($_GET, CASE_LOWER);
	if (  isset( $_get_lower['transactionid'] )  && isset( $_get_lower['paymentlinkid'] ) && isset( $_get_lower['woo_orderid'] ) && isset( $_get_lower['status'] ) ) {
		if ( ! empty( $_get_lower['transactionid'] ) && ! empty( $_get_lower['paymentlinkid'] ) && ! empty( $_get_lower['woo_orderid'] ) ) {
			$html                 = '';
			$transactionid        = sanitize_text_field( wp_unslash( $_get_lower['transactionid'] ) );
			$paymentlinkid        = sanitize_text_field( wp_unslash( $_get_lower['paymentlinkid'] ) );
			$woo_orderid          = sanitize_text_field( wp_unslash( $_get_lower['woo_orderid'] ) );
			$db_matching_order_id = '';

			$mamopay_link_id_before_payment = 'mamopay_link_id_before_payment';
			$postdata                       = $wpdb->get_results( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE  meta_key = %s AND meta_value = %s", $mamopay_link_id_before_payment, $paymentlinkid ) );
			if ( isset( $postdata['0']->post_id ) ) {
				$db_matching_order_id = $postdata['0']->post_id;
			} 

			$payment_status = sanitize_text_field( wp_unslash( $_get_lower['status'] ) );
			if ( 'captured' === $payment_status ) {
				if ( ( $db_matching_order_id === $woo_orderid ) && ! empty( $db_matching_order_id ) ) {
					update_post_meta( $woo_orderid, 'mamopay_transactionid_afterpayment', $transactionid );
					update_post_meta( $woo_orderid, 'mamopay_paymentlinkid_afterpayment', $paymentlinkid );
					$subscription_id = get_post_meta( $woo_orderid, 'mamopay_payment_subscription_identifier', true );
					$order           = wc_get_order( $woo_orderid );
					$order->payment_complete();
					wc_maybe_reduce_stock_levels( $woo_orderid );
					$order_status = $order->get_status();

					$is_added_payment_note = get_post_meta( $woo_orderid, 'mamopayordernote', true );
					if ( empty( $is_added_payment_note ) ) {
						$note = __( 'Payment completed by Mamo Pay.' );
						$order->add_order_note( $note );
						update_post_meta( $woo_orderid, 'mamopayordernote', 'added' );
					} 
					WC()->cart->empty_cart();
				} 
			} else {
				$is_failed_payment_note = get_post_meta( $woo_orderid, 'mamopay_failed_ordernote', true );
				if ( empty( $is_failed_payment_note ) ) {
					$note2 = __( 'Payment failed by Mamo Pay.' );
					$order->add_order_note( $note2 );
					update_post_meta( $woo_orderid, 'mamopay_failed_ordernote', 'added' );
				} 
			} 

			if ( empty( $order_status ) ) {
				$order_status = 'Issue in Payment';
			} 
			$orderid_txt        = __( 'Order Id', 'mamo-pay' );
			$orderstatus_txt    = __( 'Order Status', 'mamo-pay' );
			$paymntstatus_txt   = __( 'Payment Status', 'mamo-pay' );
			$transactionid_txt  = __( 'Transaction Id', 'mamo-pay' );
			$subscriptionid_txt = __( 'Subscription Id', 'mamo-pay' );
			$order_status       = __( $order_status, 'mamo-pay' );
			$payment_status     = __( $payment_status, 'mamo-pay' );

			$notice_txt = __( 'Please note your Order id and Transaction id for future reference.', 'mamo-pay' );

			$html .= '<br><table class="mamopay_orderstatus">
			<tr><td>' . $orderid_txt . ': </td><td>' . $woo_orderid . '</td></tr>
			<tr><td>' . $orderstatus_txt . ': </td><td>' . $order_status . '</td></tr>
			<tr><td>' . $paymntstatus_txt . ': </td><td>' . $payment_status . '</td></tr>
			<tr><td>' . $transactionid_txt . ': </td><td>' . $transactionid . '</td></tr>';
			if ( ! empty( $subscription_id ) ) {
				$html .= '<tr><td>' . $subscriptionid_txt . ': </td><td>' . $subscription_id . '</td></tr>';
			} 
			$html   .= '<tr><td colspan = "2"><i>' . $notice_txt . '</i></td></tr>
			</table>';
			$new_str = $str . $html;
			return $new_str;
		} 
	} 
} 



/**
 * Functon to check the payment status. This function will change woocommerce order status when user will come back to website after make payment on Mamo Pay
 */
add_action( 'init', 'mamopay_orderprocessing_init'); 

/**
 * Mamopay_orderprocessing
 *
 * @param string $str Describe what this parameter is.
 * @param string $order Describe what this parameter is.
 */
function mamopay_orderprocessing_init() {
	global $wp, $wpdb;
	$_get_lower = array_change_key_case($_GET, CASE_LOWER);
	if (  isset( $_get_lower['transactionid'] )  && isset( $_get_lower['paymentlinkid'] ) && isset( $_get_lower['woo_orderid'] ) && isset( $_get_lower['status'] ) ) {
		if ( ! empty( $_get_lower['transactionid'] ) && ! empty( $_get_lower['paymentlinkid'] ) && ! empty( $_get_lower['woo_orderid'] ) ) {
			$html                 = '';
			$transactionid        = sanitize_text_field( wp_unslash( $_get_lower['transactionid'] ) );
			$paymentlinkid        = sanitize_text_field( wp_unslash( $_get_lower['paymentlinkid'] ) );
			$woo_orderid          = sanitize_text_field( wp_unslash( $_get_lower['woo_orderid'] ) );
			$db_matching_order_id = '';

			$mamopay_link_id_before_payment = 'mamopay_link_id_before_payment';
			$postdata                       = $wpdb->get_results( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE  meta_key = %s AND meta_value = %s", $mamopay_link_id_before_payment, $paymentlinkid ) );
			if ( isset( $postdata['0']->post_id ) ) {
				$db_matching_order_id = $postdata['0']->post_id;
			} 

			$payment_status = sanitize_text_field( wp_unslash( $_get_lower['status'] ) );
			if ( 'captured' === $payment_status ) {
				if ( ( $db_matching_order_id === $woo_orderid ) && ! empty( $db_matching_order_id ) ) {
					update_post_meta( $woo_orderid, 'mamopay_transactionid_afterpayment', $transactionid );
					update_post_meta( $woo_orderid, 'mamopay_paymentlinkid_afterpayment', $paymentlinkid );
					$subscription_id = get_post_meta( $woo_orderid, 'mamopay_payment_subscription_identifier', true );
					$order           = wc_get_order( $woo_orderid );
					$order->payment_complete();
					wc_maybe_reduce_stock_levels( $woo_orderid );
					$order_status = $order->get_status();

					$is_added_payment_note = get_post_meta( $woo_orderid, 'mamopayordernote', true );
					if ( empty( $is_added_payment_note ) ) {
						$note = __( 'Payment completed by Mamo Pay.' );
						$order->add_order_note( $note );
						update_post_meta( $woo_orderid, 'mamopayordernote', 'added' );
					} 
					WC()->cart->empty_cart();
				} 
			} else {
				$is_failed_payment_note = get_post_meta( $woo_orderid, 'mamopay_failed_ordernote', true );
				if ( empty( $is_failed_payment_note ) ) {
					$note2 = __( 'Payment failed by Mamo Pay.' );
					$order->add_order_note( $note2 );
					update_post_meta( $woo_orderid, 'mamopay_failed_ordernote', 'added' );
				} 
			} 
		} 
	} 
} 




/** Mamopay_enable_manager */
function mamopay_enable_manager() {
	if ( is_admin() ) {
		return;
	} 
	if ( ! is_checkout() ) {
		return;
	} 

	$all_product_type = array();
	$all_product_ids  = array();
	$unset            = false;
	foreach ( WC()->cart->get_cart_contents() as $key => $item ) {
		if ( isset( $item['product_id'] ) ) {
			$product_type       = wc_get_product( $item['product_id'] )->get_type();
			$all_product_type[] = $product_type;
			$all_product_ids[]  = $item['product_id'];
		} 
	} 
	if ( ( ! in_array( 'subscription', $all_product_type ) ) && ( ! in_array( 'variable-subscription', $all_product_type ) ) ) {
		return;
	} else {
		foreach ( $all_product_type as $this_product_type ) {
			if ( ( 'subscription' !== $this_product_type ) && ( 'variable-subscription' !== $this_product_type ) ) {
				$unset = true;
			} 
		} 

		/* all subscriptions should be one type */
		array_unique( $all_product_ids );
		if ( count( $all_product_ids ) > '1' ) {
			$unset = true;
		} 
	} 

	if ( true === $unset ) {
		return 'disable payment button';
	} 
} 

add_filter( 'woocommerce_order_button_html', 'custom_order_button_text', 99 );
/** Custom_order_button_text
 *
 * @param string $button Describe what this parameter is.
 */
function custom_order_button_text( $button ) {
	if ( is_admin() ) {
		return;
	} 
	if ( ! is_checkout() ) {
		return;
	} 
	$chosen_payment_method = WC()->session->get( 'chosen_payment_method' );
	if ( 'mamopay' === $chosen_payment_method ) {
		$enable_disable = mamopay_enable_manager();
		if ( 'disable payment button' === $enable_disable ) {
			?>
			<i class="mamopay_instruction_warning"><?php esc_html_e( 'To pay by Mamopay, please choose either products OR subscription. Please update your cart accordingly.', 'mamopay' ); ?></i>
			<script type="text/javascript">
				jQuery("#place_order").prop('disabled', true);
				jQuery("#mamo-checkout_1").prop('disabled', true);
			</script>
			<?php
		} 
	} 

	/* jQuery code: Disable button "on change" event  */
	?>
	<script type="text/javascript">
	(function($){
		$( 'form.checkout' ).on( 'change', 'input[name^="payment_method"]', function() {
			var t = { updateTimer: !1,  dirtyInput: !1,
				reset_update_checkout_timer: function() {
					clearTimeout(t.updateTimer)
				},  trigger_update_checkout: function() {
					t.reset_update_checkout_timer(), t.dirtyInput = !1,
					$(document.body).trigger("update_checkout")
				} 
			};
			t.trigger_update_checkout();
		});
	})(jQuery);
	</script>
	<?php

	return $button;
} 

// https://siteurl.com/wp-json/mamopay-wp/downgradesubscription .
add_action(
	'rest_api_init',
	function() {
		register_rest_route(
			'mamopay-wp',
			'downgradesubscription',
			array(
				'methods'             => 'POST',
				'permission_callback' => function( $request ) {
					return true;
				},
				'callback'            => 'mamopay_downgrade_subscription_by_api',
			)
		);
	} 
);


/** Mamo_pay_get_post_id_from_meta
 *
 * @param string $meta_key Describe what this parameter is.
 * @param string $meta_value Describe what this parameter is.
 */
function mamo_pay_get_post_id_from_meta( $meta_key, $meta_value ) {
	global $wpdb;
	return $wpdb->get_var(
		$wpdb->prepare(
			"SELECT post_id 
			FROM {$wpdb->prefix}postmeta 
			WHERE meta_key = %s 
			AND meta_value = %s ",
			$meta_key,
			$meta_value
		)
	);
} 

/** Webhook to cancel subscription */
function mamopay_downgrade_subscription_by_api() {
	$posted_datapost                = json_decode( file_get_contents( 'php://input' ), true );
	$mamopay_subscription_status    = $posted_datapost['status'];
	$mamopay_subscription_charge_id = $posted_datapost['id'];  /* MamoPay side subscription transaction id */
	$mamopay_subscription_id        = $posted_datapost['subscription_id'];  /* MamoPay side subscription transaction id */
	$mamopay_subscription_amount    = $posted_datapost['amount'];

	if ( 'failed' === $mamopay_subscription_status ) {
		$order_id = mamo_pay_get_post_id_from_meta( 'mamopay_payment_subscription_identifier', $mamopay_subscription_id );
		if ( ! empty( $order_id ) ) {
			$payment_method = get_post_meta( $order_id, '_payment_method', true );
			if ( 'mamopay' === $payment_method ) {
				$order = wc_get_order( $order_id );
				if ( wcs_order_contains_subscription( $order ) ) {
					$subscriptions = wcs_get_subscriptions_for_order( $order_id );
					foreach ( $subscriptions as $subscription_id => $subscription ) {
						$subscription_id = $subscription->get_id();
						$subscription->update_status( 'on-hold' );
					} 
				} 
				$response = array(
					'status'          => '1',
					'message'         => 'Subscription Suspended',
					'id'              => $mamopay_subscription_charge_id,
					'subscription_id' => $mamopay_subscription_id,
				);
				echo wp_json_encode( $response );
				exit;
			} 
		} 
	} else {
		$response = array(
			'status'          => '0',
			'message'         => 'Subscription not changed',
			'id'              => $mamopay_subscription_charge_id,
			'subscription_id' => $mamopay_subscription_id,
		);
		echo wp_json_encode( $response );
		exit;
	} 
	exit;
} 

/* webhook to cancel subscription  // */
add_action( 'woocommerce_subscription_status_updated', 'mamopay_on_cancel_subscription', 99, 3 );

/** Mamopay_on_cancel_subscription
 *
 * @param string $subscription Describe what this parameter is.
 * @param string $new_status Describe what this parameter is.
 * @param string $old_status Describe what this parameter is.
 */
function mamopay_on_cancel_subscription( $subscription, $new_status, $old_status ) {
	if ( 'pending-cancel' === $new_status || 'cancelled' === $new_status ) {
		$subscription_id = $subscription->get_id();
		$order_id        = method_exists( $subscription, 'get_parent_id' ) ? $subscription->get_parent_id() : $subscription->order->id;

		$payment_method = get_post_meta( $order_id, '_payment_method', true );
		if ( 'mamopay' === $payment_method ) {
			$mamopay_subscription_id = get_post_meta( $order_id, 'mamopay_payment_subscription_identifier', true );
			$mamopay_settings        = get_option( 'woocommerce_mamopay_settings' );

			if ( ! empty( $mamopay_settings ) ) {
				$mamopay_enable_sandbox = $mamopay_settings['mamopay_enable_sandbox'];
				if ( 'yes' === $mamopay_enable_sandbox ) {
					$url            = "https://sandbox.business.mamopay.com/manage_api/v1/subscriptions/$mamopay_subscription_id/cancel";
					$mamopay_apikey = $mamopay_settings['mamopay_apikey_sandbox'];
				} else {
					$url            = "https://business.mamopay.com/manage_api/v1/subscriptions/$mamopay_subscription_id/cancel";
					$mamopay_apikey = $mamopay_settings['mamopay_apikey_live'];
				} 
			} 

			$headers = array(
				'Content-Type'   => 'application/json; charset=utf-8',
				'content-length' => 0,
				'timeout'        => 10000,
				'Authorization'  => 'Bearer ' . $mamopay_apikey,
			);

			$post_fields = array();
			$response    = wp_remote_request(
				$url,
				array(
					'headers'     => $headers,
					'body'        => $post_fields,
					'method'      => 'PUT',
					'data_format' => 'body',
				)
			);

			$cancel_response = json_decode( $response['body'] );
			if ( isset( $cancel_response->success ) ) {
				echo esc_html( __( 'Subscription Cancelled.', 'mamo-pay' ) );
			} else {
				echo esc_html( __( 'error', 'mamo-pay' ) );
			} 
		} 
	} 
} 

/** Mamopay_remove_my_subscriptions_button
 *
 * @param string $actions Describe what this parameter is.
 * @param string $subscription Describe what this parameter is.
 */
function mamopay_remove_my_subscriptions_button( $actions, $subscription ) {
	$subscription_id = $subscription->get_id();
	$order_id        = method_exists( $subscription, 'get_parent_id' ) ? $subscription->get_parent_id() : $subscription->order->id;

	$payment_method = get_post_meta( $order_id, '_payment_method', true );
	if ( 'mamopay' === $payment_method ) {
		foreach ( $actions as $action_key => $action ) {
			switch ( $action_key ) {
				case 'change_payment_method':	// Hide "Change Payment Method" button?
				case 'resubscribe':		// Hide "Resubscribe" button from an expired or cancelled subscription?
				case 'reactivate':		// Hide "Reactive" button on subscriptions that are "on-hold"?
					unset( $actions[ $action_key ] );
					break;
				default:
					error_log( '-- $action = ' . print_r( $action, true ) );
					break;
			} 
		} 
	} 

	return $actions;
} 
add_filter( 'wcs_view_subscription_actions', 'mamopay_remove_my_subscriptions_button', 100, 2 );



add_action( 'wp_enqueue_scripts', 'ameliaaddon_admin_localize_script' );

/** Ameliaaddon_admin_localize_script */
function ameliaaddon_admin_localize_script() {
	wp_localize_script(
		'mamopay_js',
		'mamopay_obj',
		array(
			'ajaxurl' => esc_url( home_url() ) . '/wp-admin/admin-ajax.php',
			'uid'     => get_current_user_id(),
		)
	);
} 

add_action( 'wp_head', 'mamopay_checkoutjs' );

/** Mamopay_checkoutjs */
function mamopay_checkoutjs() {
	if ( is_checkout() || is_cart() ) {
		$site_url = site_url();
		?>
		<div class="mamopay_iframe_main_div">
			<div class="mamopay_iframe_container">
				<iframe id="iframe-mamo-checkout" src="" style="display: none;    z-index: 99;    position: absolute; border-radius: 30px  " height="100%" width="100%" title="MamoPay Payment" crossorigin="anonymous"></iframe> 
			</div>
		</div>
		<div class="mamopay_iframe_loader"><i><?php echo esc_html( __( 'Preparing your order', 'mamo-pay' ) ); ?></i>
			<br><div class="mamopay_loader_inner"></div>
		</div>
		<?php
	} 
} 
