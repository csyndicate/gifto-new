<?php
// @codingStandardsIgnoreFile
// phpcs:ignoreFile
/**
 * Mamo Pay Lts WooCommerce Extension
 *
 * @package    mamo-pay
 *
 * @link   http://www.mamopay.com/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly .
} 

/*
 * This action hook registers our PHP class as a WooCommerce payment gateway
 */
	add_filter( 'woocommerce_payment_gateways', 'mamopay_add_gateway_class' );
	/** Mamopay_add_gateway_class
	 *
	 * @param string $gateways Describe what this parameter is.
	 */
function mamopay_add_gateway_class( $gateways ) {
	$gateways[] = 'WC_Mamopay_Gateway';
	return $gateways;
} 

	/*
	 * The class itself, please note that it is inside plugins_loaded action hook
	 */
	add_action( 'plugins_loaded', 'mamopay_init_gateway_class', 20 );

	/** Mamopay_init_gateway_class */
function mamopay_init_gateway_class() {
	/** WC_Mamopay_Gateway */
	class WC_Mamopay_Gateway extends WC_Payment_Gateway {

		/**
		 * Class constructor, more about it in Step 3
		 */
		public function __construct() {
			$mamopaycreditimg = CWEB_WS_PATH1 . 'public/assets/img/payment_methods.png';
			$img              = "<img class='mamopay_main_image_icon' src='$mamopaycreditimg'>";

			$this->id = 'mamopay'; // payment gateway plugin ID .
			/**
			*
			* This filter hook registers our icon as a WooCommerce payment gateway icon
			*
			* @since 3.0.0
			*/
			$this->icon               = apply_filters( 'woocommerce_gateway_icon', $mamopaycreditimg );
			$this->has_fields         = true; // in case you need a custom credit card form .
			$this->method_title       = __( 'Mamo Business', 'mamo-pay' );
			$this->method_description = __( 'Mamo Business API extension configuration', 'mamo-pay' ); // will be displayed on the options page .

			$this->supports = array(
				'products',
				'subscriptions',
				'subscription_cancellation',
				'subscription_suspension',
				'subscription_reactivation',
				'subscription_amount_changes',
				'subscription_date_changes',
				'subscription_payment_method_change',
				'subscription_payment_method_change_admin',
				'multiple_subscriptions',
			);

			// Method with all the options fields .
			$this->init_form_fields();

			// Load the settings.
			$this->init_settings();
			$this->title   = __( 'Pay by card', 'mamo-pay' );
			// $this->enabled = $this->get_option( 'enabled' );

			$this->mamopay_name                    = $this->get_option( 'mamopay_name' );
			$this->mamopay_description             = $this->get_option( 'mamopay_description' );
			$this->mamopay_apiurl_live             = $this->get_option( 'mamopay_apiurl_live' );
			$this->mamopay_apiurl_sandbox          = $this->get_option( 'mamopay_apiurl_sandbox' );
			$this->mamopay_enable_sandbox          = $this->get_option( 'mamopay_enable_sandbox' );
			$this->mamopay_apikey_live             = $this->get_option( 'mamopay_apikey_live' );
			$this->mamopay_enable_tabby            = $this->get_option( 'mamopay_enable_tabby' );
			// $this->mamopay_enable_message          = $this->get_option( 'mamopay_enable_message' );
			// $this->mamopay_enable_tips             = $this->get_option( 'mamopay_enable_tips' );
			// $this->mamopay_enable_customer_details = $this->get_option( 'mamopay_enable_customer_details' );
			// $this->mamopay_send_customer_receipt   = $this->get_option( 'mamopay_send_customer_receipt' );

			// This action hook saves the settings .
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

			// We need custom JavaScript to obtain a token .
			add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );

			// You can also register a webhook here.
			add_action( 'woocommerce_api_mamopaypaymentwebhookipn', array( $this, 'webhook' ) );

		} 

		/**
		 * These function will show form fields in woocommerce admin panel  payment settings page.
		 */
		public function init_form_fields() {
			$return_url        = wc_get_endpoint_url( 'order-received', '', wc_get_checkout_url() );
			$this->form_fields = array(
				// 'enabled'                           => array(
				// 	'title'       => __( 'Enable', 'mamo-pay' ) . '/' . __( 'Disable', 'mamo-pay' ),
				// 	'label'       => __( 'Enable Mamo Business Payment Gateway', 'mamo-pay' ),
				// 	'type'        => 'checkbox',
				// 	'description' => '',
				// 	'default'     => 'no',
				// ),
				'mamopay_name'                      => array(
					'title'             => __( 'Name', 'mamo-pay' ),
					'type'              => 'text',
					'custom_attributes' => array(
						'required'  => true,
						'maxlength' => '50',
					),
				),

				'mamopay_description'               => array(
					'title'             => __( 'Description', 'mamo-pay' ),
					'type'              => 'text',
					'custom_attributes' => array(
						'required'  => true,
						'maxlength' => '75',
					),
				),

				'mamopay_enable_sandbox'            => array(
					'title'       => __( 'Sandbox Mode', 'mamo-pay' ),
					'label'       => __( 'Enable Sandbox Mode', 'mamo-pay' ) . '<span class="slider round"></span>',
					'type'        => 'checkbox',
					'description' => '<i>' . __( 'Enable to switch to the Sandbox environment for pre production testing', 'mamo-pay' ) . '</i>',
					'default'     => 'no',
					'class'       => 'mamopay_live_sandbox_toggle',
				),

				'mamopay_apiurl_live'               => array(
					'title'   => __( 'Env URL', 'mamo-pay' ),
					'type'    => 'text',
					'default' => 'https://business.mamopay.com/manage_api/v1/links',
					'class'   => 'mamopay_liveurlclass mamopayurladmin',
				),

				'mamopay_apikey_live'               => array(
					'title'       => __( 'API Key', 'mamo-pay' ),
					'type'        => 'text',
					'description' => '<i>' . __( 'Login to the Mamo Business Dashboard > Developer > API Key', 'mamo-pay' ) . '</i>',
					'class'       => 'mamopay_livekeyclass',
				),

				'mamopay_apiurl_sandbox'            => array(
					'title'   => __( 'Env URL', 'mamo-pay' ),
					'type'    => 'text',
					'default' => 'https://sandbox.business.mamopay.com/manage_api/v1/links',
					'class'   => 'mamopay_sandbox_urlclass mamopayurladmin',
				),

				'mamopay_enable_googlepay_applepay' => array(
					'title'       => __( 'Apple and Google Pay', 'mamo-pay' ),
					'label'       => __( 'Enable Apple and Google Pay', 'mamo-pay' ),
					'type'        => 'checkbox',
					'description' => '<i>' . __( 'Enables Apple and Google Pay as a separate payment option', 'mamo-pay' ) . '</i>',
					'default'     => 'no',
				),

				'mamopay_enable_tabby' => array(
					'title'       => __( 'Tabby', 'mamo-pay' ),
					'label'       => __( '[PREMIUM ONLY] Enable Tabby (BNPL) for customers on checkout', 'mamo-pay' ),
					'type'        => 'checkbox',
					'description' => '<i>' . __( 'Note that this option is only avaiable for Premium Mamo Business users', 'mamo-pay' ) . '</i>',
					'default'     => 'no',
				),

				// 'mamopay_enable_message'            => array(
				// 	'title'       => __( 'Message', 'mamo-pay' ),
				// 	'label'       => __( 'Enable Adding a Message', 'mamo-pay' ),
				// 	'type'        => 'checkbox',
				// 	'description' => '<i>Your customers will be required to add a message during the checkout process</i>',
				// 	'default'     => 'no',
				// ),

				// 'mamopay_enable_tips'               => array(
				// 	'title'       => __( 'Tips', 'mamo-pay' ),
				// 	'label'       => __( 'Enable Tips', 'mamo-pay' ),
				// 	'type'        => 'checkbox',
				// 	'description' => '<i>' . __( 'Allows your customers to add tips on top of the payment amount. This will be displayed on the first screen', 'mamo-pay' ) . '</i>',
				// 	'default'     => 'no',
				// ),

				// 'mamopay_enable_customer_details'   => array(
				// 	'title'       => __( 'Customer Details', 'mamo-pay' ),
				// 	'label'       => __( 'Enable Adding Customer Details', 'mamo-pay' ),
				// 	'type'        => 'checkbox',
				// 	'description' => __( 'Your customers will be required to enter their name, email, and phone number. This screen will be displayed before the payment details screen', 'mamo-pay' ),
				// 	'default'     => 'no',
				// ),

				// 'mamopay_send_customer_receipt'     => array(
				// 	'title'       => __( 'Send Customer Receipt', 'mamo-pay' ),
				// 	'label'       => __( 'Enable Sending Customer Receipts', 'mamo-pay' ),
				// 	'type'        => 'checkbox',
				// 	'description' => 'Whether your customers will receive a receipt from Mamo. This will be in addition to any receipt that you will be sending to them',
				// 	'default'     => 'no',
				// ),
			);
		} 




		/** Payment_fields */
		public function payment_fields() {
			$mamopay_enable_googlepay_applepay = $this->get_option( 'mamopay_enable_googlepay_applepay' );

			/**
			 * Action hook to adjust text before checkout.
			 *
			 * @since 3.0.0
			 */
			do_action( 'mamopay_checout_text_start', $this->id );
			/**
			 * Action hook to adjust text after checkout.
			 *
			 * @since 3.0.0
			 */
			do_action( 'mamopay_checout_text_end', $this->id );

			echo '<div class="clear"></div>';

			?>
			<fieldset id="wc-<?php echo esc_attr( $this->id ); ?>-payment_options" class="wc-payfixy-form wc-payment-form" style="background:transparent;">
			<div class="cstm_mamopaysub_outer">
				<?php
				if ( 'yes' === $mamopay_enable_googlepay_applepay ) {
					?>
					<div class="cstm_mamopaysub">
						<input type="radio" checked="checked" class="change_mamopay_sub" id="mamopay_sub_cardpayment" name="selected_mamo_payment_method" required value="mamopay_sub_cardpayment">
						<label for="mamopay_sub_cardpayment">
							<span> <?php esc_html_e( 'Pay by Card', 'mamo-pay' ); ?></span>
						</label>
						<img class="mamopay_img_paybycard" src="<?php echo esc_html(CWEB_WS_PATH1 . 'public/assets/img/payment_method_cards.png', 'mamo-pay'); ?>" alt="Pay by card">
					</div>
					
					<br>
					<div class="cstm_mamopaysub">
						<input type="radio" class="change_mamopay_sub" id="mamopay_sub_walletpayment" name="selected_mamo_payment_method" required value="mamopay_sub_walletpayment">
						<label for="mamopay_sub_walletpayment" >
							<span><?php esc_html_e( 'Pay by Wallet', 'mamo-pay' ); ?></span>
						</label>
						<img class="mamopay_img_apple_google_pay" src="<?php echo esc_html(CWEB_WS_PATH1 . 'public/assets/img/payment_method_apple_google_pay.png', 'mamo-pay'); ?>" alt="Pay by Wallet (google pay / Apple Pay)">
					</div>
					
					<?php
				} else {
					?>
					<div class="cstm_mamopaysub">
						<input type="radio" class="change_mamopay_sub" checked="checked" id="mamopay_sub_cardpayment" name="selected_mamo_payment_method" required value="mamopay_sub_cardpayment">
						<label for="mamopay_sub_cardpayment">
							<span><?php esc_html_e( 'Pay by Card', 'mamo-pay' ); ?></span>
						</label>
						<img class="mamopay_img_paybycard" src="<?php echo esc_html(CWEB_WS_PATH1 . 'public/assets/img/payment_method_cards.png', 'mamo-pay'); ?>" alt="Pay by card">
					</div>
					
					<?php
				} 
				?>
			</div>
			<div class="clear"></div>
			<?php wp_nonce_field( 'mamopay_nonce', 'mamopay_nonce' ); ?> 
		</fieldset>
			<?php
		} 

		/** Payment_scripts */
		public function payment_scripts() {
			// we need JavaScript to process a token only on cart/checkout pages, right?
			if ( ! is_cart() && ! is_checkout() ) {
				return;
			} 

			// if our payment gateway is disabled, we do not have to enqueue JS too.
			if ( 'no' === $this->enabled ) {
				return;
			} 

		} 


		/** Process_payment
		 *
		 * @param string $order_id Describe what this parameter is.
		 */
		public function process_payment( $order_id ) {
			global $woocommerce;
			$order                           = wc_get_order( $order_id );
			$this->enabled                   = $this->get_option( 'enabled' );
			$mamopay_name                    = $this->mamopay_name;
			$mamopay_description             = $this->mamopay_description;
			$mamopay_apiurl_live             = $this->mamopay_apiurl_live;
			$mamopay_apiurl_sandbox          = $this->mamopay_apiurl_sandbox;
			$mamopay_enable_sandbox          = $this->mamopay_enable_sandbox;
			$mamopay_returnurl               = wc_get_endpoint_url( 'order-received', $order_id, wc_get_checkout_url() );
			$mamopay_apikey_live             = $this->mamopay_apikey_live;
			$mamopay_enable_tabby			 = $this->mamopay_enable_tabby;
			$billing_first_name 			 = $order->get_billing_first_name();
			$billing_last_name 				 = $order->get_billing_last_name();
			$billing_email   	 			 = $order->get_billing_email();
			// $mamopay_enable_message          = $this->mamopay_enable_message;
			// $mamopay_enable_tips             = $this->mamopay_enable_tips;
			// $mamopay_enable_customer_details = $this->mamopay_enable_customer_details;
			// $mamopay_send_customer_receipt   = $this->mamopay_send_customer_receipt;
			// we need it to get any order detailes.
			$order_meta                 = get_post_meta( $order_id );
			$order_key                  = get_post_meta( $order_id, '_order_key', true );
			$items                      = $order->get_items();
			$final_subscriptions_length = '0';
			$cstm_subscription_array    = array();
			$key_of_max                 = 0;

			$order_date 				= $order->order_date;
			
			foreach ( $items as $item_id => $item_data ) {
				$product            = wc_get_product( $item_data->get_product_id() );
				$productdescription = get_post( $item_data['product_id'] )->post_content;
				$product_title      = $item_data['name'];
				if ( class_exists( 'WC_Subscriptions_Product' ) && WC_Subscriptions_Product::is_subscription( $product ) ) {
					$subscription_period       = WC_Subscriptions_Product::get_period( $item_data->get_product_id() );
					$subscriptions_length      = WC_Subscriptions_Product::get_length( $item_data->get_product_id() );
					$billing_cycle             = WC_Subscriptions_Product::get_interval( $item_data->get_product_id() );  /** How many times within the period to bill */
					$subscription_exp_date     = WC_Subscriptions_Product::get_expiration_date( $product, $order_date );
					$cstm_subscription_array[] = array(
						'subscription_period'   => $subscription_period,
						'subscriptions_length'  => $subscriptions_length,
						'billing_cycle'         => $billing_cycle,
						'subscription_exp_date' => $subscription_exp_date,
					);
				} 
			} 
			$url                             = ( 'yes' === $mamopay_enable_sandbox ) ? $this->mamopay_apiurl_sandbox : $this->mamopay_apiurl_live;
			$mamopay_enable_message          = ( 'yes' === $mamopay_enable_message ) ? true : false;
			$mamopay_enable_tips             = ( 'yes' === $mamopay_enable_tips ) ? true : false;
			$mamopay_enable_customer_details = ( 'yes' === $mamopay_enable_customer_details ) ? true : false;
			$mamopay_send_customer_receipt   = ( 'yes' === $mamopay_send_customer_receipt ) ? true : false;
			$mamopay_apikey                  = $this->mamopay_apikey_live;
			$capacity = null; /* The maximum number of times this payment link can be used. Updated to null from 1 to make infinite as it was impacting subscriptions */
			$order_total                     = $order->get_total();
			$currency_symbol                 = get_woocommerce_currency_symbol();
			if ( '2' > $order_total ) {
				$t = 'Order total should not less than 2 ' . $currency_symbol;
				wc_add_notice( esc_html( $t, 'mamo-pay' ), 'error' );
				return;
			} 

			$headers                        = array(
				'Content-Type'  => 'application/json; charset=utf-8',
				'Authorization' => 'Bearer ' . $mamopay_apikey,
			);
			$post_fields                    = array(
				'name'                    => $mamopay_name,
				'description'             => $mamopay_description,
				'capacity'                => $capacity,
				'active'                  => true,
				'return_url'              => $mamopay_returnurl,
				'amount'                  => $order->get_total(),
				'amount_currency'		  => get_woocommerce_currency(),
				'enable_message'          => false,
				'enable_tips'             => false,
				'enable_customer_details' => false,
				'send_customer_receipt'   => false,
				'custom_data'             => array( 'woo_orderid' => $order_id ),
				'platform'				  => 'woocommerce',
				'enable_quantity'		  => false,
				'enable_qr_code'		  => false,
				'enable_tabby'			  => $mamopay_enable_tabby,
				'first_name'			  => $billing_first_name,
				'last_name'			  	  => $billing_last_name,
				'email'			  		  => $billing_email,
			);
			$final_subscriptions_length_new = '0';
			$subscription_array_new         = array();
			if ( function_exists( 'wcs_order_contains_subscription' ) ) {
				if ( wcs_order_contains_subscription( $order ) ) {
					$subscriptions = wcs_get_subscriptions_for_order( $order_id );
					foreach ( $subscriptions as $subscription_id => $subscription ) {
						$price_per_period       = $subscription->get_total();
						$subscription_interval  = $subscription->get_billing_interval();
						$start_timestamp        = $subscription->get_time( 'date_created' );
						$trial_end_timestamp    = $subscription->get_time( 'trial_end' );
						$next_payment_timestamp = $subscription->get_time( 'next_payment' );
						$is_synced_subscription = WC_Subscriptions_Synchroniser::subscription_contains_synced_product( $subscription->get_id() );
						$is_early_resubscribe   = false;
						if ( wcs_cart_contains_resubscribe()  ) {
							$resubscribe_cart_item 		=  wcs_cart_contains_resubscribe();
							$resubscribed_subscription 	= wcs_get_subscription( $resubscribe_cart_item['subscription_resubscribe']['subscription_id'] );
							$is_early_resubscribe      	= wcs_is_subscription( $resubscribed_subscription ) && $resubscribed_subscription->has_status( 'pending-cancel' );
						} 
						if ( $is_synced_subscription ) {
							$length_from_timestamp = $next_payment_timestamp;
						} elseif ( $trial_end_timestamp > 0 ) {
							$length_from_timestamp = $trial_end_timestamp;
						} else {
							$length_from_timestamp = $start_timestamp;
						} 
						$subscription_billing_period   = $subscription->get_billing_period();
						$subscription_endtime          = $subscription->get_time( 'end' );
						$subscription_billing_interval = $subscription->get_billing_interval();
						$subscription_length           = wcs_estimate_periods_between( $length_from_timestamp, $subscription->get_time( 'end' ), $subscription->get_billing_period() );
						if ( '0' === $subscription_endtime ) {
							$subscription_endtime          = 'Never expire';
							$subscription_payment_quantity = '';
						} else {
							$subscription_endtime          = gmdate( 'Y-m-d', $subscription->get_time( 'end' ) );
							$subscription_payment_quantity = $subscription_length / $subscription_billing_interval;
						} 
						$subscription_array_new[] = array(
							'subscription_period'   => $subscription_billing_period,
							'subscriptions_length'  => $subscription_length,
							'billing_cycle'         => $subscription_billing_interval,
							'subscription_exp_date' => $subscription_endtime,
							'subscription_payment_quantity' => $subscription_payment_quantity,
						);
					} 
					/* foreach */
					foreach ( $subscription_array_new as $keynew => $valuenew ) {
							$this_subscription_period   = $valuenew['subscription_period'];
							$this_subscriptions_length  = $valuenew['subscriptions_length'];
							$this_billing_cycle         = $valuenew['billing_cycle'];
							$this_subscription_exp_date = $valuenew['subscription_exp_date'];
							$this_payment_quantity      = $valuenew['subscription_payment_quantity'];
						if ( $this_subscriptions_length > $final_subscriptions_length_new || '0' === $this_subscriptions_length ) {
								$final_subscriptions_length = $this_subscriptions_length;
								$final_subscription_period  = $this_subscription_period;
								$final_billing_cycle        = $this_billing_cycle;
								$final_exp_date             = $this_subscription_exp_date;
								$final_payment_quantity     = $this_payment_quantity;
						} 
					} 

					$payment_quantity   = $final_subscriptions_length / $final_billing_cycle;
					$subscription_array = array();
					if ( 'day' === $final_subscription_period ) {
						$final_subscription_period = 'daily';
					} 
					if ( 'week' === $final_subscription_period ) {
						$final_subscription_period = 'weekly';
					} 
					if ( 'month' === $final_subscription_period ) {
						$final_subscription_period = 'monthly';
					} 
					if ( 'year' === $final_subscription_period ) {
						$final_subscription_period = 'annually';
					} 
					if ( 'Never expire' !== $final_exp_date ) {
						$final_exp_date = gmdate( 'Y/m/d', strtotime( $final_exp_date ) );
					} 
					$subscription_array['frequency']			= $final_subscription_period; /* defines the interval that this subscription will be run on. (annually, monthly etc )*/
					$subscription_array['frequency_interval']	= (int) $final_billing_cycle; /* defines how often this subscription will run. This will be based on the frequency property defined above.*/
					$subscription_array['end_date']				= $final_exp_date;  /* the last date this subscription could run on. */
					$subscription_array['payment_quantity']		= $final_payment_quantity; /* number of times this subscription will occur. If end_date defined, end_date takes precedence. */
					$post_fields['subscription']				= $subscription_array;
				} 
			} 

			$selected_mamo_payment_method 	= ''; 
			if ( isset( $_POST['mamopay_nonce'] ) ) { 
				if ( wp_verify_nonce( sanitize_text_field( $_POST['mamopay_nonce'] ) , 'mamopay_nonce' ) && isset( $_POST['selected_mamo_payment_method'] ) ) { 
					$selected_mamo_payment_method = sanitize_text_field( $_POST['selected_mamo_payment_method'] ); 
				} 
			} 
			
			if ( 'mamopay_sub_cardpayment' === $selected_mamo_payment_method ) {
				$post_fields['is_widget'] = true;
			} 

			$response = wp_remote_post(
				$url,
				array(
					'headers'     => $headers,
					'body'        => wp_json_encode( $post_fields ),
					'method'      => 'POST',
					'data_format' => 'body',
				)
			);

			if ( isset( $response['response'] ) ) { 
				if ( ( '201' == $response['response']['code'] ) && ( 'Created' === $response['response']['message'] ) ) { 
					$body         = $response['body'];
					$json_decoded = json_decode( $body );
					if ( isset( $json_decoded->payment_url ) ) { 
						$payment_order_id                = isset( $json_decoded->custom_data->woo_orderid ) ? $json_decoded->custom_data->woo_orderid : ''; 
						$mamopay_link_id                 = isset( $json_decoded->id ) ? $json_decoded->id : ''; 
						$payment_url                     = isset( $json_decoded->payment_url ) ? $json_decoded->payment_url : '';  
						$subscription_identifier         = isset( $json_decoded->subscription->identifier ) ? $json_decoded->subscription->identifier : ''; 
						$subscription_frequency_interval = isset( $json_decoded->subscription->frequency_interval ) ? $json_decoded->subscription->frequency_interval : ''; 
						$subscription_end_date           = isset( $json_decoded->subscription->end_date ) ? $json_decoded->subscription->end_date : '';
						$subscription_payment_quantity   = isset( $json_decoded->subscription->payment_quantity ) ? $json_decoded->subscription->payment_quantity : '';
						$subscription_frequency          = isset( $json_decoded->subscription->frequency ) ? $json_decoded->subscription->frequency : '';
						update_post_meta( $order_id, 'mamopay_link_id_before_payment', $mamopay_link_id );
						update_post_meta( $order_id, 'mamopay_payment_url_before_payment', $payment_url );
						update_post_meta( $order_id, 'mamopay_payment_subscription_identifier', $subscription_identifier );
						update_post_meta( $order_id, 'mamopay_payment_subscription_frequency_interval', $subscription_frequency_interval );
						update_post_meta( $order_id, 'mamopay_payment_subscription_end_date', $subscription_end_date );
						update_post_meta( $order_id, 'mamopay_payment_subscription_payment_quantity', $subscription_payment_quantity );
						update_post_meta( $order_id, 'mamopay_payment_subscription_frequency', $subscription_frequency );
						if ( 'mamopay_sub_cardpayment' === $selected_mamo_payment_method ) {
							$newpayment_url = $order->get_checkout_payment_url( true );
							return array(
								'result'   => 'success',
								'redirect' => '#' . $payment_url,
							);
						} else {
							return array(
								'result'   => 'success',
								'redirect' => $payment_url,
							);
						} 
						exit;
					} else {
						wc_add_notice( esc_html( 'Something went wrong. Please get in touch with us to help resolve the issue', 'mamo-pay' ), 'error' );
						return;
					} 
				} else {
					$errors_data = json_decode( $response['body'] );
					if ( isset( $errors_data->errors ) ) {
						$all_errors = $errors_data->errors;
					} else {
						$all_errors = isset( $errors_data->messages ) ? $errors_data->messages : '';
					} 
					$error_string = '';
					if ( !empty($all_errors) ) {
						foreach ( $all_errors as $key => $single_error ) {
							$error_string .= $single_error;
							$error_string .= ' ';
						} 
					} 
					
									wc_add_notice( esc_html( $error_string, 'mamo-pay' ), 'error' );
									return;
				} 
			} else {
				wc_add_notice( esc_html( 'Something went wrong. Please get in touch with us to help resolve the issue11', 'mamo-pay' ), 'error' );
				return;
			} 
		} 

		/**
		 * In case you need a webhook, like PayPal IPN etc
		 */
		public function webhook() { }
	} 
} 
